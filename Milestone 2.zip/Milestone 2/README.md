##To run the code

1. First change the user and password at the beginning of integrated.py 
2. Run the following commands:  
`sudo apt install python3.8-venv`  

3.Then create a virtual environment using the following command:  
`python3 -m venv Myenv`  

4.Now, activate this environment using:  
`source Myenv/bin/activate`  

5.One last step before running the program is to install the requirements using:  
`pip install requirements.txt`  

6.Then run the code using:  
`python3 integrated.py`
