/*
-- Query: select * from givesreviews
-- Date: 2022-04-11 23:39
*/
INSERT INTO `` (`Username`,`Rating`,`Text`,`Review_Date`,`Home_team`,`Away_Team`,`Match_Date`) VALUES ('animats','3','Better than expected but yet not that best ','2022-08-16','Leeds','Southampton','2022-04-02');
INSERT INTO `` (`Username`,`Rating`,`Text`,`Review_Date`,`Home_team`,`Away_Team`,`Match_Date`) VALUES ('bflong','10','A very great match and the goalkeeper were better than expected','2021-01-05','Spurs','West Ham','2022-03-20');
INSERT INTO `` (`Username`,`Rating`,`Text`,`Review_Date`,`Home_team`,`Away_Team`,`Match_Date`) VALUES ('boftx','5','A very great match and the goalkeeper were better than expected','2021-07-12','Chelsea','Brentford','2022-04-02');
INSERT INTO `` (`Username`,`Rating`,`Text`,`Review_Date`,`Home_team`,`Away_Team`,`Match_Date`) VALUES ('cfhsoft','4','The match didn\'t go that well','2021-01-01','Burnley','Everton','2022-04-06');
INSERT INTO `` (`Username`,`Rating`,`Text`,`Review_Date`,`Home_team`,`Away_Team`,`Match_Date`) VALUES ('cumarana','6','The match didn\'t go that well','2021-01-03','Everton','Man Utd','2022-04-09');
INSERT INTO `` (`Username`,`Rating`,`Text`,`Review_Date`,`Home_team`,`Away_Team`,`Match_Date`) VALUES ('esokullu','2','The match didn\'t go that well','2020-02-01','Man Utd','Leicester','2022-04-02');
INSERT INTO `` (`Username`,`Rating`,`Text`,`Review_Date`,`Home_team`,`Away_Team`,`Match_Date`) VALUES ('facet','8','A very great match and the goalkeeper were better than expected','2022-04-20','Southampton','Chelsea','2022-04-09');
INSERT INTO `` (`Username`,`Rating`,`Text`,`Review_Date`,`Home_team`,`Away_Team`,`Match_Date`) VALUES ('falcao','1','Not the best premieum league ever','2022-08-16','Aston Villa','Spurs','2022-04-09');
INSERT INTO `` (`Username`,`Rating`,`Text`,`Review_Date`,`Home_team`,`Away_Team`,`Match_Date`) VALUES ('flavell','6','Not the best premieum league ever','2021-01-01','Wolves','Aston Villa','2022-04-02');
INSERT INTO `` (`Username`,`Rating`,`Text`,`Review_Date`,`Home_team`,`Away_Team`,`Match_Date`) VALUES ('gozer','3','I didn\'t like the players performance','2020-04-20','Burnley','Man City','2022-04-02');
INSERT INTO `` (`Username`,`Rating`,`Text`,`Review_Date`,`Home_team`,`Away_Team`,`Match_Date`) VALUES ('jessicajohnson','3','Not the best premieum league ever','2021-08-09','Newcastle','Wolves','2022-04-09');
INSERT INTO `` (`Username`,`Rating`,`Text`,`Review_Date`,`Home_team`,`Away_Team`,`Match_Date`) VALUES ('jfmulder','2','I didn\'t like the players performance','2021-02-01','Crystal Palace','Arsenal','2022-04-05');
INSERT INTO `` (`Username`,`Rating`,`Text`,`Review_Date`,`Home_team`,`Away_Team`,`Match_Date`) VALUES ('jonadab','5','Better than expected but yet not that best ','2020-02-05','Spurs','Newcastle','2022-04-03');
INSERT INTO `` (`Username`,`Rating`,`Text`,`Review_Date`,`Home_team`,`Away_Team`,`Match_Date`) VALUES ('leeashley','1','The match didn\'t go that well','2021-11-11','Brentford','West Ham','2022-04-10');
INSERT INTO `` (`Username`,`Rating`,`Text`,`Review_Date`,`Home_team`,`Away_Team`,`Match_Date`) VALUES ('lyonspeter','1','I didn\'t like the players performance','2022-03-03','Leicester','Crystal Palace','2022-04-10');
INSERT INTO `` (`Username`,`Rating`,`Text`,`Review_Date`,`Home_team`,`Away_Team`,`Match_Date`) VALUES ('melnik','7','A very great match and the goalkeeper were better than expected','2021-03-04','West Ham','Everton','2022-04-03');
INSERT INTO `` (`Username`,`Rating`,`Text`,`Review_Date`,`Home_team`,`Away_Team`,`Match_Date`) VALUES ('monica23','8','A very great match and the goalkeeper were better than expected','2022-01-04','Norwich','Burnley','2022-04-10');
INSERT INTO `` (`Username`,`Rating`,`Text`,`Review_Date`,`Home_team`,`Away_Team`,`Match_Date`) VALUES ('perezbilly','6','Better than expected but yet not that best ','2021-10-10','Man City','Liverpool','2022-04-10');
INSERT INTO `` (`Username`,`Rating`,`Text`,`Review_Date`,`Home_team`,`Away_Team`,`Match_Date`) VALUES ('rafasgj','9','Better than expected but yet not that best ','2022-07-12','Watford','Leeds','2022-04-09');
INSERT INTO `` (`Username`,`Rating`,`Text`,`Review_Date`,`Home_team`,`Away_Team`,`Match_Date`) VALUES ('sjmuir','7','I didn\'t like the players performance','2021-02-26','Arsenal','Brighton','2022-04-09');
INSERT INTO `` (`Username`,`Rating`,`Text`,`Review_Date`,`Home_team`,`Away_Team`,`Match_Date`) VALUES ('sriha','2','The match didn\'t go that well','2021-02-26','Brighton','Norwich','2022-04-02');
INSERT INTO `` (`Username`,`Rating`,`Text`,`Review_Date`,`Home_team`,`Away_Team`,`Match_Date`) VALUES ('storerm','4','I didn\'t like the players performance','2021-05-05','Leicester','Brentford','2022-03-20');
INSERT INTO `` (`Username`,`Rating`,`Text`,`Review_Date`,`Home_team`,`Away_Team`,`Match_Date`) VALUES ('uraeus','4','Not the best premieum league ever','2000-01-07','Liverpool','Watford','2022-04-02');
