/*
-- Query: select * from fan
-- Date: 2022-04-11 23:41
*/
INSERT INTO `` (`Username`,`Email`,`Gender`,`DoB`,`ClubName`) VALUES ('animats','animats@live.com','M','1945-01-03','Blackpool');
INSERT INTO `` (`Username`,`Email`,`Gender`,`DoB`,`ClubName`) VALUES ('bflong','bflong@att.net','M','2022-08-16','Brentford');
INSERT INTO `` (`Username`,`Email`,`Gender`,`DoB`,`ClubName`) VALUES ('boftx','boftx@msn.com','M','1998-02-01','Norwich City');
INSERT INTO `` (`Username`,`Email`,`Gender`,`DoB`,`ClubName`) VALUES ('cfhsoft','cfhsoft@optonline.net','F','2022-08-16','Leeds United');
INSERT INTO `` (`Username`,`Email`,`Gender`,`DoB`,`ClubName`) VALUES ('cumarana','cumarana@icloud.com','M','1990-01-01','Everton');
INSERT INTO `` (`Username`,`Email`,`Gender`,`DoB`,`ClubName`) VALUES ('esokullu','esokullu@yahoo.ca','M','1930-04-20','AFC Bournemouth');
INSERT INTO `` (`Username`,`Email`,`Gender`,`DoB`,`ClubName`) VALUES ('facet','facet@yahoo.com','F','1978-03-04','Huddersfield Town');
INSERT INTO `` (`Username`,`Email`,`Gender`,`DoB`,`ClubName`) VALUES ('falcao','falcao@yahoo.com','M','2000-01-07','Ipswich Town');
INSERT INTO `` (`Username`,`Email`,`Gender`,`DoB`,`ClubName`) VALUES ('flavell','flavell@live.com','F','1982-02-26','Bolton Wanderers');
INSERT INTO `` (`Username`,`Email`,`Gender`,`DoB`,`ClubName`) VALUES ('gozer','gozer@gmail.com','M','1990-01-01','Newcastle United');
INSERT INTO `` (`Username`,`Email`,`Gender`,`DoB`,`ClubName`) VALUES ('jessicajohnson','aaronhopkins@hotmail.com','F','2022-08-16','Liverpool');
INSERT INTO `` (`Username`,`Email`,`Gender`,`DoB`,`ClubName`) VALUES ('jfmulder','jfmulder@comcast.net','F','1945-01-03','Leicester City');
INSERT INTO `` (`Username`,`Email`,`Gender`,`DoB`,`ClubName`) VALUES ('jonadab','jonadab@msn.com','M','1930-04-20','Manchester City');
INSERT INTO `` (`Username`,`Email`,`Gender`,`DoB`,`ClubName`) VALUES ('leeashley','tamaramorrison@hotmail.com','M','1945-01-03','Chelsea');
INSERT INTO `` (`Username`,`Email`,`Gender`,`DoB`,`ClubName`) VALUES ('lyonspeter','deborah64@gmail.com','M','1982-02-26','Arsenal');
INSERT INTO `` (`Username`,`Email`,`Gender`,`DoB`,`ClubName`) VALUES ('melnik','melnik@optonline.net','F','1982-02-26','Liverpool');
INSERT INTO `` (`Username`,`Email`,`Gender`,`DoB`,`ClubName`) VALUES ('monica23','danny30@yahoo.com','M','1930-04-20','Liverpool');
INSERT INTO `` (`Username`,`Email`,`Gender`,`DoB`,`ClubName`) VALUES ('perezbilly','epetersen@yahoo.com','F','1988-07-12','Portsmouth');
INSERT INTO `` (`Username`,`Email`,`Gender`,`DoB`,`ClubName`) VALUES ('rafasgj','rafasgj@live.com','M','1980-02-05','Hull City');
INSERT INTO `` (`Username`,`Email`,`Gender`,`DoB`,`ClubName`) VALUES ('sjmuir','sjmuir@me.com','F','1998-02-01','Fulham');
INSERT INTO `` (`Username`,`Email`,`Gender`,`DoB`,`ClubName`) VALUES ('sriha','sriha@yahoo.com','M','2022-08-16','Middlesbrough');
INSERT INTO `` (`Username`,`Email`,`Gender`,`DoB`,`ClubName`) VALUES ('storerm','storerm@optonline.net','M','1988-07-12','Bradford City');
INSERT INTO `` (`Username`,`Email`,`Gender`,`DoB`,`ClubName`) VALUES ('uraeus','uraeus@optonline.net','M','1988-07-12','Manchester United');
